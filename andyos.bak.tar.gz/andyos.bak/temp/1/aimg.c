/*
 * aimg.c
 * 创建 a.img 软盘虚拟映像文件，包含Boot Sector，大小为1.44MB
 */
#include <stdio.h>

int main()
{
	int i;
	int len;
	FILE* fp;
	char buffer[512];
	char bufferz[512];
	for (i=0; i<512; i++) {
		bufferz[i] = 0;
	}
	
	/* 以二进制只读模式打开 "boot.bin" 文件 */
	fp = fopen("boot.bin", "rb");
	if (!fp) {
		printf("fail to open \"boot.bin\"!\n");
		return 0;
	}

	/* 读取文件大小，确保小于510字节 */
	fseek(fp, 0, SEEK_END);
	len = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	if (len > 510) {
		printf("\"boot.bin\" is too large!\n");
		fclose(fp);
		return 0;
	}
	
	/* 读取 "boot.bin" 文件，关闭文件 */
	fread(&buffer, len, 1, fp);
	fclose(fp);

	/* 以二进制写模式创建 "a.img" 文件 */
	fp = fopen("a.img", "wb");	
	if (!fp) {
		printf("fail to create \"a.img\"!\n");
		return 0;
	}

	/* 写 "a.img" 第0号扇区，以0xAA55结尾，用0填充 */
	fwrite(&buffer, len, 1, fp);
	fwrite(&bufferz, 510-len, 1, fp);
	buffer[0] = 0x55;
	buffer[1] = 0xAA;
	fwrite(&buffer, 2, 1, fp);

	/* 写 "a.img" 剩余扇区，共80*2*18个扇区，关闭文件 */
	for (i=0; i<80*2*18-1; i++) {
		fwrite(&bufferz, 512, 1, fp);
	}
	fclose(fp);	

	return 0;
}
