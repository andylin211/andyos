#include <stdio.h>

int main()
{
	int i;
	int count = 0;
	int len;
	int sector = 0;
	char buffer[512];
	char bufferz[512];
	FILE* fp = 0;
	FILE* fpb = 0;
	FILE* fpk = 0;
	for (i=0; i<512; i++) {
		bufferz[i] = 0;
	}

	fp = fopen("a.img", "wb");
	if (fp == 0) {
		printf("fail to create \"a.img\"\n");
		return 0;
	}
	fpb = fopen("boot.bin", "rb");
	if (fpb == 0) {
		printf("fail to read \"boot.bin\"\n");
		fclose(fp);
		return 0;
	}
	fpk = fopen("kernel.bin", "rb");
	if (fpk == 0) {
		printf("fail to read \"kernel.bin\"\n");
		fclose(fp);
		fclose(fpb);
		return 0;
	}

	fseek(fpb, 0, SEEK_END);
	len = ftell(fpb);
	fseek(fpb, 0, SEEK_SET);
	if (len > 510) {
		printf("\"boot.bin\" too large!");
		fclose(fp);
		fclose(fpb);
		fclose(fpk);
		return 0;
	}
	fread(&buffer, len, 1, fpb);
	fclose(fpb);
	fwrite(&buffer, len, 1, fp);
	fwrite(&bufferz, 510-len, 1, fp);
	buffer[0] = 0x55;
	buffer[1] = 0xAA;
	fwrite(&buffer, 2, 1, fp);
	count = 1;

	fseek(fpk, 0, SEEK_END);
	len = ftell(fpk);
	fseek(fpk, 0, SEEK_SET);
	sector = len / 512 + 1;
	printf("\"kernel.bin\" %d bytes, %d sectors.\n", len, sector);

	*(int*)bufferz = sector;
	fwrite(&bufferz, 512, 1, fp);
	count = 2;
	*(int*)bufferz = 0;
	
	while (len > 0) {
		if (len >= 512) {
			fread(&buffer, 512, 1, fpk);
			fwrite(&buffer, 512, 1, fp);
			len -= 512;
		}
		else {
			fread(&buffer, len, 1, fpk);
			fwrite(&buffer, len, 1, fp);
			fwrite(&bufferz, 512-len, 1, fp);
			len = 0;
		}
		count++;
	}
	fclose(fpk);

	for (i=count; i<80*18*2; i++) {
		fwrite(&bufferz, 512, 1, fp);
	}
	fclose(fp);
	printf("\"a.img\" OK!\n");
	return 0;
}
