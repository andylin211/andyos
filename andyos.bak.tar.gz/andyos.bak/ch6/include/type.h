#ifndef	_TYPE_H_
#define	_TYPE_H_

#include "const.h"

typedef	unsigned char	u8;
typedef unsigned short	u16;
typedef unsigned int	u32;

typedef void (*int_handler)();
typedef void (*task_f)();
typedef void (*irq_handler)(int irq);
typedef void* system_call;


//protect
typedef struct s_descriptor
{
	u16	limit_low;
	u16	base_low;
	u8	base_mid;
	u8	attr1;
	u8	limit_high_attr2;
	u8	base_high;
}DESCRIPTOR;

typedef struct s_gate
{
	u16	offset_low;
	u16	selector;
	u8	dcount;
	u8	attr;
	u16	offset_high;
}GATE;

typedef struct s_tss
{
	u32	backlink;
	u32	esp0;
	u32	ss0;
	u32	esp1;
	u32	ss1;
	u32	esp2;
	u32	ss2;
	u32	cr3;
	u32	eip;
	u32	flags;
	u32	eax;
	u32	ecx;
	u32	edx;
	u32	ebx;
	u32	esp;
	u32	ebp;
	u32	esi;
	u32	edi;
	u32	es;
	u32	cs;
	u32	ss;
	u32	ds;
	u32	fs;
	u32	gs;
	u32	ldt;
	u16	trap;
	u16	iobase;
}TSS;

//proc
typedef struct s_stackframe {
	u32	gs;
	u32	fs;
	u32	es;
	u32	ds;
	u32	edi;
	u32	esi;
	u32	ebp;
	u32	kernel_esp;
	u32	ebx;
	u32	edx;
	u32	ecx;
	u32	eax;
	u32	retaddr;
	u32	eip;
	u32	cs;
	u32	eflags;
	u32	esp;
	u32	ss;
}STACK_FRAME;

typedef struct s_proc {
	STACK_FRAME 	regs;
	u16		ldt_sel;
	DESCRIPTOR	ldts[LDT_SIZE];
	int		ticks;
	int		priority;
	u32		pid;
}PROCESS;

typedef struct s_task {
	task_f		initial_eip;
	int		stacksize;
}TASK;


#endif
