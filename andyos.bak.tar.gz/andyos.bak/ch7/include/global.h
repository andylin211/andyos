#ifndef	_GLOBAL_H_
#define _GLOBAL_H_

#include "type.h"
#include "const.h"

extern u32 		disp_pos;
extern u8		gdt_ptr[6];
extern DESCRIPTOR	gdt[GDT_SIZE];
extern u8		idt_ptr[6];
extern GATE		idt[IDT_SIZE];

extern TSS		tss;
extern PROCESS*		p_proc_ready;

extern PROCESS		proc_table[];
extern TASK		task_table[];
extern char		task_stack[];
extern int		k_reenter;
extern irq_handler	irq_table[NR_IRQ];
extern system_call	sys_call_table[NR_SYS_CALL];

extern u32		ticks;

extern TTY		tty_table[NR_CONSOLES];
extern CONSOLE		console_table[NR_CONSOLES];
extern u32		nr_current_console;

#endif
