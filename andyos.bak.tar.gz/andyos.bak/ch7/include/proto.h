#ifndef _PROTO_H_
#define _PROTO_H_

#include "const.h"
#include "type.h"

//protect.c
PUBLIC void	init_prot();
PUBLIC void	put_irq_handler();

//clock.c
PUBLIC void clock_handler(int irq);
PUBLIC void milli_delay(int milli_sec);
PUBLIC void init_clock();

//keyboard.c
PUBLIC void init_keyboard();

//tty
PUBLIC void task_tty();
PUBLIC void in_process(TTY* p_tty, u32 key);
PUBLIC int sys_write(char* buf, int len, PROCESS* p_proc);

//proc.c
PUBLIC int sys_get_ticks();
PUBLIC void schedule();
PUBLIC void TestA();
PUBLIC void TestB();
PUBLIC void TestC();

//kernel.asm
PUBLIC void restart();
PUBLIC int get_ticks();
PUBLIC void write(char* buf, int len);
PUBLIC void sys_call();
PUBLIC void save();
PUBLIC void divide_error();
PUBLIC void single_step_exception();
PUBLIC void nmi();
PUBLIC void breakpoint_exception();
PUBLIC void overflow();
PUBLIC void bounds_check();
PUBLIC void inval_opcode();
PUBLIC void copr_not_available();
PUBLIC void double_fault();
PUBLIC void copr_seg_overrun();
PUBLIC void inval_tss();
PUBLIC void segment_not_present();
PUBLIC void stack_exception();
PUBLIC void general_protection();
PUBLIC void page_fault();
PUBLIC void copr_error();
PUBLIC void hwint00();
PUBLIC void hwint01();
PUBLIC void hwint02();
PUBLIC void hwint03();
PUBLIC void hwint04();
PUBLIC void hwint05();
PUBLIC void hwint06();
PUBLIC void hwint07();
PUBLIC void hwint08();
PUBLIC void hwint09();
PUBLIC void hwint10();
PUBLIC void hwint11();
PUBLIC void hwint12();
PUBLIC void hwint13();
PUBLIC void hwint14();
PUBLIC void hwint15();

//lib
PUBLIC void	out_byte(u16 port, u8 value);
PUBLIC u8	in_byte(u16 port);
PUBLIC void	disable_irq(int irq);
PUBLIC void	enable_irq(int irq);
PUBLIC char*	memcpy(void* p_dst, void* p_src, int count);
PUBLIC void	memset(void* p_dst, char ch, int size);
PUBLIC void	enable_int();
PUBLIC void 	disable_int();
PUBLIC void	strcpy(char* p_dst, const char* p_src);
PUBLIC int	strlen(const char* str);



#endif
