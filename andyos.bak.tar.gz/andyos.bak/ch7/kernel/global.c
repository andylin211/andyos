#include "proto.h"
#include "global.h"


PUBLIC	u32		disp_pos = 0;

PUBLIC	u8		gdt_ptr[6];

PUBLIC	DESCRIPTOR	gdt[GDT_SIZE];

PUBLIC	u8		idt_ptr[6];

PUBLIC	GATE		idt[IDT_SIZE];

PUBLIC	TSS		tss;

PUBLIC	PROCESS*	p_proc_ready;

PUBLIC	PROCESS		proc_table[NR_TASKS];

PUBLIC	TASK		task_table[NR_TASKS] = {{TestA, STACK_SIZE_TEST},
						{TestB, STACK_SIZE_TEST},
						{TestC, STACK_SIZE_TEST},
						{task_tty, STACK_SIZE_TEST}};

PUBLIC	char		task_stack[STACK_SIZE_TOTAL];

PUBLIC	int		k_reenter;

PUBLIC	irq_handler	irq_table[NR_IRQ];

PUBLIC	system_call	sys_call_table[NR_SYS_CALL] = { sys_get_ticks,
							sys_write};

PUBLIC	u32		ticks;

PUBLIC	TTY		tty_table[NR_CONSOLES];

PUBLIC	CONSOLE		console_table[NR_CONSOLES];

PUBLIC	u32		nr_current_console;
