#include "proto.h"
#include "global.h"
#include "keymap.h"

PRIVATE KB_INPUT kb_in;
PRIVATE int	shift_l;
PRIVATE int	shift_r;
PRIVATE	int	alt_l;
PRIVATE int	alt_r;
PRIVATE int	ctrl_l;
PRIVATE int	ctrl_r;
PRIVATE int	code_with_E0;
PRIVATE int	caps_lock;
PRIVATE int	num_lock;
PRIVATE int	scroll_lock;
PRIVATE int	column;

PUBLIC void keyboard_handler(int irq)
{
	u8 scan_code = in_byte(KB_DATA);
	if (kb_in.count < KB_IN_BYTES) {
		*kb_in.p_head = scan_code;
		kb_in.p_head++;
		if (kb_in.p_head == kb_in.buf + KB_IN_BYTES) {
			kb_in.p_head = kb_in.buf;
		}
		kb_in.count++;
//		disp_int(kb_in.count);
	}
}

PRIVATE u8 get_byte_from_kbuf()
{
	u8 scan_code;
	while (kb_in.count <= 0) {
//		milli_delay(1);
//		disp_str("_");
	}
//	disp_str("iloveyouh");
	
	disable_int();	//kb_in is shared resource
	scan_code = *(kb_in.p_tail);
	kb_in.p_tail++;
	if (kb_in.p_tail == kb_in.buf + KB_IN_BYTES) {
		kb_in.p_tail = kb_in.buf;
	}
	kb_in.count--;
	enable_int();
	return scan_code;
}


PUBLIC void keyboard_read(TTY* p_tty)
{
	int	make;
	char	output[2] = {0, 0};
	u8 scan_code;
	u32	key;
	u32*	keyrow;
	int	i;

	//disp_int(kb_in.count);
	//scan_code = get_byte_from_kbuf();
	if (kb_in.count > 0) {
		code_with_E0 = FALSE;
		scan_code = get_byte_from_kbuf();
		if (scan_code == 0xE1) {
			//impossible for me
		}
		else if (scan_code == 0xE0) {
			scan_code = get_byte_from_kbuf();
			code_with_E0 = TRUE;
		}
		{
			make	= (scan_code & FLAG_BREAK ? FALSE : TRUE);
			keyrow	= &keymap[(scan_code & 0x7F) * MAP_COLS];
			column	= 0;
			if (shift_l || shift_l) {
				column = 1;
			}
			if (code_with_E0) {
				column = 2;
			}
			key = keyrow[column];
			switch (key) {
			case SHIFT_L:
				shift_l = make;
				break;
			case SHIFT_R:
				shift_r = make;
				break;
			case CTRL_L:
				ctrl_l = make;
				break;
			case CTRL_R:
				ctrl_r = make;
				break;
			case ALT_L:
				alt_l = make;
				break;
			case ALT_R:
				alt_r = make;
				break;
			default:
				break;
			}
			if (make) {
				key |= shift_l ? FLAG_SHIFT_L : 0;
				key |= shift_r ? FLAG_SHIFT_R : 0;
				key |= ctrl_l ? FLAG_CTRL_L : 0;
				key |= ctrl_r ? FLAG_CTRL_R : 0;
				key |= alt_l ? FLAG_ALT_L : 0;
				key |= alt_r ? FLAG_ALT_R : 0;
				in_process(p_tty, key);
			}
		}
	}
}

PUBLIC void init_keyboard()
{
	kb_in.count = 0;
	kb_in.p_head = kb_in.p_tail = kb_in.buf;
	shift_l = shift_r = FALSE;
	alt_l = alt_r = FALSE;
	ctrl_l = ctrl_r = FALSE;
	code_with_E0 = FALSE;
	caps_lock = num_lock = scroll_lock = FALSE;
	column = 0;

	put_irq_handler(KEYBOARD_IRQ, keyboard_handler);
}
