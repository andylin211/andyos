#include "proto.h"
#include "global.h"

#define TTY_FIRST	(tty_table)
#define TTY_END		(tty_table+NR_CONSOLES)

PRIVATE void init_tty(TTY* p_tty);
PRIVATE void tty_do_read(TTY* p_tty);
PRIVATE void tty_do_write(TTY* p_tty);

PUBLIC void task_tty()
{
	TTY*	p_tty;
	init_keyboard();
	for (p_tty=TTY_FIRST; p_tty<TTY_END; p_tty++) {
		init_tty(p_tty);
	}
	nr_current_console = 0;
	while (1) {
		for (p_tty=TTY_FIRST; p_tty<TTY_END; p_tty++) {
			tty_do_read(p_tty);
			tty_do_write(p_tty);
		}
	}
}

PRIVATE void set_cursor(u32 pos)
{
	disable_int();
	out_byte(CRTC_ADDR_REG, CURSOR_H);
	out_byte(CRTC_DATA_REG, (pos >> 8) & 0xFF);
	out_byte(CRTC_ADDR_REG, CURSOR_L);
	out_byte(CRTC_DATA_REG, pos & 0xFF);
	enable_int();
}

PRIVATE void set_video_start_addr(u32 addr)
{
	disable_int();
	out_byte(CRTC_ADDR_REG, START_ADDR_H);
	out_byte(CRTC_DATA_REG, (addr >> 8) & 0xFF);
	out_byte(CRTC_ADDR_REG, START_ADDR_L);
	out_byte(CRTC_DATA_REG, addr & 0xFF);
	enable_int();
}


PRIVATE void out_char(CONSOLE* p_con, char ch)
{
	u8* p_vmem	= (u8*)(V_MEM_BASE + p_con->cursor*2);

	switch (ch) {
	case '\n':
		if (p_con->cursor < p_con->original_addr + p_con->v_mem_limit - SCREEN_WIDTH) {
			p_con->cursor = p_con->original_addr + SCREEN_WIDTH * 
					((p_con->cursor - p_con->original_addr) / SCREEN_WIDTH + 1);
		}
		break;
	case '\b':
		if (p_con->cursor > p_con->original_addr) {
			p_con->cursor--;
			*(p_vmem-2) = ' ';
		}
		break;
	default:
		if (p_con->cursor < p_con->original_addr + p_con->v_mem_limit - 1) {
			*p_vmem++	= ch;
			*p_vmem++	= 0x4F;
			p_con->cursor++;
		}
		break;
	}

	set_cursor(p_con->cursor);
	set_video_start_addr(p_con->current_start_addr);
}

PRIVATE void put_key(TTY* p_tty, u32 key) 
{
	if (p_tty->count < TTY_IN_BYTES) {
		*(p_tty->p_head) = key;
		p_tty->p_head++;
		if (p_tty->p_head == p_tty->buf + TTY_IN_BYTES) {
			p_tty->p_head = p_tty->buf;
		}
		p_tty->count++;
	}
}

PRIVATE void init_screen(TTY* p_tty)
{
	int nr_tty = p_tty - tty_table;
	p_tty->p_console = console_table + nr_tty;

	int v_mem_size = V_MEM_SIZE >> 1;

	int con_v_mem_size		= v_mem_size / NR_CONSOLES;
	p_tty->p_console->original_addr = nr_tty * con_v_mem_size;
	p_tty->p_console->v_mem_limit	= con_v_mem_size;
	p_tty->p_console->current_start_addr	= p_tty->p_console->original_addr;

	p_tty->p_console->cursor = p_tty->p_console->original_addr;
	if (nr_tty == 0) {
		p_tty->p_console->cursor = disp_pos / 2;
		disp_pos = 0;
	}
	else {
		out_char(p_tty->p_console, nr_tty + '0');
		out_char(p_tty->p_console, '#');
	}

	set_cursor(p_tty->p_console->cursor);
}

PRIVATE void init_tty(TTY* p_tty)
{
	p_tty->count = 0;
	p_tty->p_head = p_tty->p_tail = p_tty->buf;
	
	init_screen(p_tty);
}


PRIVATE void select_console(int nr_console)
{
	if ((nr_console < 0) || (nr_console >= NR_CONSOLES)) {
		return;
	}
	nr_current_console = nr_console;
	set_cursor(console_table[nr_console].cursor);
	set_video_start_addr(console_table[nr_console].current_start_addr);
}

PUBLIC void in_process(TTY* p_tty, u32 key)
{
	if (!(key & FLAG_EXT)) {
		put_key(p_tty, key);
	}
	else {
		int raw_code = key & MASK_RAW;
		switch (raw_code) {
		case ENTER:
			put_key(p_tty, '\n');
			break;
		case BACKSPACE:
			put_key(p_tty, '\b');
			break;
		case F1:
		case F2:
		case F3:
		case F4:
		case F5:
		case F6:
		case F7:
		case F8:
		case F9:
		case F10:
		case F11:
		case F12:
			select_console(raw_code - F1);
		break;
		}
	}
}

PRIVATE int is_current_console(CONSOLE* p_con)
{
	return (p_con == &console_table[nr_current_console]);
}

PRIVATE void tty_do_read(TTY* p_tty)
{
	if (is_current_console(p_tty->p_console)) {
		keyboard_read(p_tty);
	}
}

PRIVATE void tty_do_write(TTY* p_tty)
{
	char ch;
	if (p_tty->count) {
		ch = *(p_tty->p_tail);
		p_tty->p_tail++;
		if (p_tty->p_tail == p_tty->buf + TTY_IN_BYTES) {
			p_tty->p_tail = p_tty->buf;
		}
		p_tty->count--;
		out_char(p_tty->p_console, ch);
	}
}

PUBLIC void tty_write(TTY* p_tty, char* buf, int len)
{
	char* p = buf;
	int i = len;
	while (i) {
		out_char(p_tty->p_console, *p++);
		i--;
	}
}

PUBLIC int sys_write(char* buf, int len, PROCESS* p_proc)
{
	tty_write(&tty_table[p_proc->nr_tty], buf, len);
	return 0;
}

