#include "proto.h"


PUBLIC char* itoa(char* str, int num)
{
	char* p = str;
	char  ch;
	int   i;
	int   flag = 0;

	*p = '0';
	++p;
	*p = 'x';
	++p;

	if (num == 0) {
		*p = '0';
		++p;
	}
	else {
		for (i=28; i>=0; i-=4) {
			ch = (num >> i) & 0xF;
			if (flag || (ch > 0)) {
				flag = 1;
				ch += '0';
				if (ch > '9') {
					ch += 7;
				}
				*p = ch;
				++p;
			}
		}
	}
	*p = 0;
	return str;
}

PUBLIC void disp_int(int input)
{
	char output[16];
	itoa(output, input);
	disp_str(output);
}

PRIVATE int vsprintf(char* buf, const char* fmt, char* args);

PUBLIC int printf(const char *fmt, ...)
{
	int i;
	char buf[256];

	char* arg = (char*)((char*)(&fmt) + 4);
	i = vsprintf(buf, fmt, arg);
	write(buf, i);

	return i;
}

PRIVATE int vsprintf(char* buf, const char* fmt, char* args)
{
	char* p;
	char tmp[256];
	char* p_next_arg = args;

	for (p=buf; *fmt; fmt++) {
		if (*fmt != '%') {
			*p++ = *fmt;
			continue;
		}

		fmt++;

		switch (*fmt) {
		case 'x':
			itoa(tmp, *((int*)p_next_arg));
			strcpy(p, tmp);
			p_next_arg += 4;
			p += strlen(tmp);
			break;
		case 's':
			break;
		default:
			break;
		}
	}
	return (p-buf);
}
