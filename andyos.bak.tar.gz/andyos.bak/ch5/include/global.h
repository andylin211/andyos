#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#include "type.h"
#include "const.h"
#include "protect.h"

#ifdef _GLOBAL_VARIABLE_HERE_
#undef EXTERN
#define EXTERN
#endif

EXTERN u32 		disp_pos;
EXTERN u8		gdt_ptr[6];
EXTERN DESCRIPTOR	gdt[GDT_SIZE];
EXTERN u8		idt_ptr[6];
EXTERN GATE		idt[IDT_SIZE];


#endif
