#ifndef _PROTO_H_
#define _PROTO_H_

PUBLIC void disp_str(char* str);
PUBLIC void out_byte(u16 port, u8 value);
PUBLIC u8 in_byte(u16 port);

#endif
