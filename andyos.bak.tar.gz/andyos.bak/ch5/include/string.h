#ifndef _STRING_H_
#define _STRING_H_

char* memcpy(char* pDst, char* pSrc, int count);

#endif
