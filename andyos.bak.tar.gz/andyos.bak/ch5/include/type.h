#ifndef	_TYPE_H_
#define	_TYPE_H_

typedef	unsigned char	u8;
typedef unsigned short	u16;
typedef unsigned int	u32;

typedef void (*int_handler)();


#endif
