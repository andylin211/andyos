#define _GLOBAL_VARIABLE_HERE_

#include "type.h"
#include "const.h"
#include "protect.h"
#include "proto.h"
#include "global.h"

