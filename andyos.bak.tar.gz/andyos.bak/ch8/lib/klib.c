#include "proto.h"

PRIVATE int vsprintf(char* buf, const char* fmt, char* args);

PUBLIC void* memcpy(void* dst, void* src, int size)
{
	int i;
	char* _dst = (char*)dst;
	char* _src = (char*)src;
	for (i=0; i<size; i++) {
		_dst[i] = _src[i];
	}
	return dst;
}

PUBLIC void memset(void* dst, char ch, int size)
{
	int i;
	char* _dst = (char*)dst;
	for (i=0; i<size; i++) {
		_dst[i] = ch;
	}
}

PUBLIC char* strcpy(char* dst, const char* src)
{
	char* ret = dst;
	while (*src) {
		*dst++ = *src++;
	}
	return ret;
}

PUBLIC int strlen(const char* src)
{
	const char* p = src;
	while (*p) {
		p++;
	}
	return (p - src);
}

PUBLIC char* i2a(int val, int base, char** ps)
{
	int m = val % base;
	int q = val / base;
	if (q) {
		i2a(q, base, ps);
	}
	*(*ps)++ = (m < 10) ? (m + '0') : (m - 10 + 'A');
	*(*ps) = 0;
	return *ps;
}

PUBLIC void printf(const char *fmt, ...)
{
	char	buf[256];
	char	tmp[256];
	char*	p;
	int	m;
	char	cs;
	int	align_nr;
	char*	args = (char*)((char*)(&fmt) + 4);
	char*	p_arg = args;
	char	inner_buf[1024];

	for (p=buf; *fmt; fmt++) {
		if (*fmt != '%') {
			*p++ = *fmt;
			continue;
		}
		else {
			align_nr = 0;
		}
		fmt++;

		if (*fmt == '%') {
			*p++ = *fmt;
			continue;
		}
		else if (*fmt == '0') {
			cs = '0';
			fmt++;
		}
		else {
			cs = ' ';
		}
		while (((u8)(*fmt) >= '0') && ((u8)(*fmt) <= '9')) {
			align_nr *= 10;
			align_nr += *fmt - '0';
		}
		char* q = inner_buf;
		memset(q, 0, sizeof(inner_buf));

		switch (*fmt) {
		case 'c':
			*q++ = *((char*)p_arg);
			p_arg += 4;
			break;
		case 'x':
			m = *((int*)p_arg);
			i2a(m, 16, &q);
			p_arg += 4;
			break;
		case 'd':
			m = *((int*)p_arg);
			if (m < 0) {
				m = 0 - m;
				*q++ = '-';
			}
			i2a(m, 10, &q);
			p_arg += 4;
			break;
		case 's':
			strcpy(q, (*((char**)p_arg)));
			q += strlen(*((char**)p_arg));
			p_arg += 4;
			break;
		default:
			break;
		}

		int k;
		for (k=0;
		     k < ((align_nr > strlen(inner_buf)) ? (align_nr - strlen(inner_buf)) : 0); 
		     k++) {
			*p++ = cs;
		}
		q = inner_buf;
		while (*q) {
			*p++ = *q++;
		}
	}
	*p = 0;
	printx(buf);
}

PUBLIC void assertion_failure(char* exp, char* file, char* base_file, int line)
{
	printf("assert(%s) failed: file: %s, base_file: %s, ln%d",
		exp, file, base_file, line);
	__asm__ __volatile("hlt");
}
