#include "proto.h"
#include "global.h"


PRIVATE int msg_send(PROCESS* current, int dest, MESSAGE* m);
PRIVATE int msg_recv(PROCESS* current, int src, MESSAGE* m);

PUBLIC int get_ticks()
{
	MESSAGE msg;
	msg.type = GET_TICKS;
	send_recv(BOTH, 0, &msg);
	return msg.retval;
}

PUBLIC void sys_printx(const char* buf)
{
	u8* p = (u8*)(0xB8000 + cursor * 2);
	while (*buf) {
		switch (*buf) {
		case '\n':
			if (cursor * 2 + 160 < 0x10000) {
				cursor = (cursor / 80 + 1) * 80;
			}
			break;
		default:
			if (cursor * 2 + 2 < 0x10000) {
				*p++ = *buf;
				*p++ = 0x07;
				cursor++;
			}
			break;
		}
		buf++;
	}
	disable_int();
	out_byte(0x3D4, 0xE);
	out_byte(0x3D5, (cursor>>8) & 0xFF);
	out_byte(0x3D4, 0xF);
	out_byte(0x3D5, cursor & 0xFF);
	enable_int();
}
			

PUBLIC void schedule()
{
	PROCESS* p = p_proc_ready;
	p->ticks = p->priority;
	while (1) {
		p++;
		if (p == proc_table + NR_TASKS) {
			p = proc_table;
		}
		if (p->p_flags == 0) {
			break;
		}
	}
	p_proc_ready = p;
}

PUBLIC int init_proc()
{
	TASK*		p_task		= task_table;
	PROCESS* 	p_proc		= proc_table;
	char*		p_task_stack	= task_stack + STACK_SIZE_TOTAL;
	u16		selector_ldt	= SELECTOR_LDT_FIRST;
	int i;

	for (i=0; i<NR_TASKS; i++) {
		p_proc->ldt_sel = selector_ldt;
		memcpy(&p_proc->ldts[0], &gdt[SELECTOR_KERNEL_CS >> 3], sizeof(DESCRIPTOR));
		p_proc->ldts[0].attr1 = DA_C | PRIVILEGE_TASK << 5;
		memcpy(&p_proc->ldts[1], &gdt[SELECTOR_KERNEL_DS >> 3], sizeof(DESCRIPTOR));
		p_proc->ldts[1].attr1 = DA_DRW | PRIVILEGE_TASK << 5;

		p_proc->regs.cs = (0 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | SA_RPL1;
		p_proc->regs.ds = (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | SA_RPL1;
		p_proc->regs.es = (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | SA_RPL1;
		p_proc->regs.fs = (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | SA_RPL1;
		p_proc->regs.ss = (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | SA_RPL1;
		p_proc->regs.gs = (SELECTOR_KERNEL_GS & SA_RPL_MASK) | SA_RPL1;
		p_proc->regs.eip = (u32)p_task->initial_eip;
		p_proc->regs.esp = (u32)p_task_stack;
		p_proc->regs.eflags = 0x1202;

		p_proc->p_flags	= 0;
		p_proc->p_recvfrom = 0;
		p_proc->p_sendto = 0;
		p_proc->q_sending = 0;
		p_proc->next_sending = 0;
		p_proc->has_int_msg = 0;

		p_task_stack -= p_task->stacksize;
		p_proc++;
		p_task++;
		selector_ldt += 8;
	}
	k_reenter = 0;
	p_proc_ready = proc_table;

	proc_table[0].ticks = proc_table[0].priority = 10;
	proc_table[1].ticks = proc_table[1].priority = 20;
	proc_table[2].ticks = proc_table[2].priority = 20;
	proc_table[3].ticks = proc_table[3].priority = 50;

	init_clock();

	restart();
}

/**
 * The core routine of system call sendrec()
 * @param function	SEND or RECEIVE
 * @param src_dest	To/From whom the message is transferred.
 * @param m		Ptr to the MESSAGE body.
 * @param p		The caller proc.
 * @return 0 if success.
 */
PUBLIC int sys_sendrec(int function, int src_dest, MESSAGE* m, PROCESS* p)
{
	assert(k_reenter == 0);	/* make sure we are not in ring0 when call sendrec() */
	assert((src_dest >= 0 && src_dest < NR_TASKS) || 
		src_dest == ANY || src_dest == INTERRUPT);

	int ret = 0;
	int caller = p - proc_table;
	m->source = caller;

	assert(m->source != src_dest);

	if (function == SEND) {
		ret = msg_send(p, src_dest, m);
		if (ret != 0) {
			return ret;
		}
	}
	else if (function == RECEIVE) {
		ret = msg_recv(p, src_dest, m);
		if (ret != 0) {
			return ret;
		}
	}
	else {
		assert(0);
	}

	return 0;
}


/**
 * IPC syscall. It is encapsulation of 'sendrec', invoking 'sendrec' directly should be avoided.
 * @param function 	SEND, RECEIVE or BOTH
 * @param src_dest	The caller's proc_nr
 * @param msg		Ptr to the MESSAGE body
 * @return always 0
 */
PUBLIC int send_recv(int function, int src_dest, MESSAGE* msg)
{
	int ret = 0;
	if (function == RECEIVE) {
		memset(msg, 0, sizeof(MESSAGE));
	}
	switch (function) {
	case BOTH:
		ret = sendrec(SEND, src_dest, msg);
		if (ret == 0) {
			ret = sendrec(RECEIVE, src_dest, msg);
		}
		break;
	case SEND:
	case RECEIVE:
		ret = sendrec(function, src_dest, msg);
		break;
	default:
		assert(0);
		break;
	}
	return ret;
}

PRIVATE void block(PROCESS* p)
{
	assert(p->p_flags);
	schedule();
}

PRIVATE void unblock(PROCESS* p)
{
	assert(p->p_flags == 0);
}

/**
 * Check whether it's safe to send a message from src to dest.
 * The routine will detect if the messging graph contains a cycle.
 * @param src		Who wants to send msg
 * @param dest		To whom the msg is sent
 * @return 0 if success.
 */
PRIVATE int deadlock(int src, int dest)
{
	PROCESS* p = proc_table + dest;
	while (1) {
		if (p->p_flags & SENDING) {
			if (p->p_sendto == src) {
				return 1;
			}
			p = proc_table + p->p_sendto;
		}
		else {
			break;
		}
	}
	return 0;
}

/**
 * Send a msg to the dest proc. 
 * If dest is blocked wating for the msg, copy the message to it and unblock dest. 
 * Otherwise the caller will be blocked and appended to the dest's sending queue.
 * @param current	The caller, the sender.
 * @param dest		To whom the msg is sent.
 * @param m		msg
 * @return 0 if success.
 */
PRIVATE int msg_send(PROCESS* current, int dest, MESSAGE* m)
{
	PROCESS* sender = current;
	PROCESS* p_dest = proc_table + dest;
	int src = sender - proc_table;
	assert(src != dest);
	assert(deadlock(src, dest) == 0);
	if ((p_dest->p_flags & RECEIVING) &&
		(p_dest->p_recvfrom == src || p_dest->p_recvfrom == ANY)) {
		assert(p_dest->p_msg);
		assert(m);
		memcpy(p_dest->p_msg, m, sizeof(MESSAGE));
		p_dest->p_msg = 0;
		p_dest->p_flags &= ~RECEIVING;
		p_dest->p_recvfrom = NO_TASK;
		unblock(p_dest);
	}
	else {
		sender->p_flags |= SENDING;
		assert(sender->p_flags == SENDING);
		sender->p_sendto = dest;
		sender->p_msg = m;
		
		PROCESS* p;
		if (p_dest->q_sending) {
			p = p_dest->q_sending;
			while (p->next_sending) {
				p = p->next_sending;
			}
			p->next_sending = sender;
		}
		else {
			p_dest->q_sending = sender;
		}
		sender->next_sending = 0;
		block(sender);
	}
	return 0;
}

/**
 * Try to get a msg from the src proc.
 * If src is blocked sending the msg, copy the message from it and unblock it.
 * Otherwise the caller will be blocked.
 * @param current	The caller, the receiver
 * @param src		From whom the msg will be received
 * @param m		msg
 * @return 0 if success.
 */
PRIVATE int msg_recv(PROCESS* current, int src, MESSAGE* m)
{
	PROCESS* p_recver = current;
	PROCESS* p_from;
	PROCESS* prev = 0;
	int copyok = 0;
	int dest = p_recver - proc_table;

	assert(dest != src);
	if ((p_recver->has_int_msg) && ((src == ANY) || (src == INTERRUPT))) {
		MESSAGE msg;
		memset(&msg, 0, sizeof(MESSAGE));
		msg.source = INTERRUPT;
		msg.type = HARD_INT;
		assert(m);
		memcpy(m, &msg, sizeof(MESSAGE));
		
		p_recver->has_int_msg = 0;
		return 0;
	}
	if (src = ANY) {
		if (p_recver->q_sending) {
			p_from = p_recver->q_sending;
			copyok = 1;
		}
	}
	else {
		p_from = proc_table + src;
		if ((p_from->p_flags & SENDING) && (p_from->p_sendto == dest)) {
			copyok = 1;
			PROCESS* p = p_recver->q_sending;
			assert(p);
			while (p) {
				assert(p_from->p_flags & SENDING);
				if (dest == src) {
					p_from = p;
					break;
				}
				prev = p;
				p = p->next_sending;
			}
		}
	}
	if (copyok) {
		if (p_from == p_recver->q_sending) {
			assert(prev == 0);
			p_recver->q_sending = p_from->next_sending;
		}
		else {
			assert(prev);
			prev->next_sending = p_from->next_sending;
		}
		p_from->next_sending = 0;
		assert(m);
		assert(p_from->p_msg);
		memcpy(m, p_from->p_msg, sizeof(MESSAGE));
		p_from->p_msg = 0;
		p_from->p_sendto = NO_TASK;
		p_from->p_flags &= ~SENDING;
		unblock(p_from);
	}
	else {
		p_recver->p_flags |= RECEIVING;
		p_recver->p_msg = m;
		if (src == ANY) {
			p_recver->p_recvfrom = ANY;
		}
		else {
			p_recver->p_recvfrom = src;
		}
		block(p_recver);
	}
	return 0;
}

void TestA()
{
	while (1) {
		printf("A");
		milli_delay(500);
	}
}

void TestB()
{
	while (1) {
		printf("B");
		milli_delay(1000);
	}
}

void TestC()
{
	while (1) {
		printf("C");
		milli_delay(2000);
	}
}
