#include "global.h"
#include "proto.h"

PUBLIC void task_sys()
{
	MESSAGE msg;
	while (1) {
		send_recv(RECEIVE, ANY, &msg);
		int src = msg.source;
		switch (msg.type) {
		case GET_TICKS:
			msg.retval = ticks;
			send_recv(SEND, src, &msg);
			break;
		default:
			assert(0);
			break;
		}
	}
}
