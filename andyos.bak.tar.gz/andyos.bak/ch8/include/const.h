#ifndef _CONST_H_
#define _CONST_H_

#define	PUBLIC
#define	PRIVATE	static

#define	GDT_SIZE	128
#define IDT_SIZE	256

#define INT_M_CTL	0x20
#define INT_M_CTLMASK	0x21
#define INT_S_CTL	0xA0
#define INT_S_CTLMASK	0xA1

#define EOI		0x20

#define PRIVILEGE_KRNL	0
#define PRIVILEGE_TASK	1
#define PRIVILEGE_USER	3

#define RPL_KRNL	0
#define RPL_TASK	1
#define RPL_USER	3

#define NR_IRQ		16

#define NR_SYS_CALL	2

#define TIMER0		0x40
#define TIMER_MODE	0x43
#define RATE_GENERATOR	0x34
#define TIMER_FREQ	1193182L
#define HZ		100

#define NR_TASKS	4

#define STACK_SIZE_TEST		0x8000
#define STACK_SIZE_TOTAL	(STACK_SIZE_TEST * NR_TASKS)

//protect
#define SELECTOR_DUMMY		0
#define SELECTOR_FLAT_C		0x8
#define	SELECTOR_FLAT_RW	0x10
#define	SELECTOR_VIDEO		(0x18+3)
#define	SELECTOR_TSS		0x20
#define SELECTOR_LDT_FIRST	0x28

#define	SELECTOR_KERNEL_CS	SELECTOR_FLAT_C
#define	SELECTOR_KERNEL_DS	SELECTOR_FLAT_RW
#define SELECTOR_KERNEL_GS	SELECTOR_VIDEO

#define LDT_SIZE		2


#define SA_RPL_MASK		0xFFFC
#define SA_RPL0			0
#define SA_RPL1			1
#define SA_RPL2			2
#define SA_RPL3			3

#define SA_TI_MASK		0xFFFB
#define SA_TIG			0
#define	SA_TIL			4

#define	DA_32			0x4000
#define	DA_LIMIT_4K		0x8000
#define	DA_DPL0			0x00
#define	DA_DPL1			0x20
#define	DA_DPL2			0x40
#define	DA_DPL3			0x60

#define	DA_DR			0x90
#define	DA_DRW			0x92
#define	DA_DRWA			0x93
#define	DA_C			0x98
#define	DA_CR			0x9A
#define	DA_CCO			0x9C
#define	DA_CCOR			0x9E

#define	DA_LDT			0x82
#define DA_TaskGate		0x85
#define	DA_386TSS		0x89
#define	DA_386CGate		0x8C
#define DA_386IGate		0x8E
#define	DA_386TGate		0x8F

#define INT_VECTOR_DIVIDE	0x0
#define INT_VECTOR_DEBUG	0x1
#define	INT_VECTOR_NMI		0x2
#define	INT_VECTOR_BREAKPOINT	0x3
#define	INT_VECTOR_OVERFLOW	0x4
#define	INT_VECTOR_BOUNDS	0x5
#define	INT_VECTOR_INVAL_OP	0x6
#define INT_VECTOR_COPROC_NOT	0x7
#define	INT_VECTOR_DOUBLE_FAULT	0x8
#define	INT_VECTOR_COPROC_SEG	0x9
#define	INT_VECTOR_INVAL_TSS	0xA
#define INT_VECTOR_SEG_NOT	0xB
#define	INT_VECTOR_STACK_FAULT	0xC
#define	INT_VECTOR_PROTECTION	0xD
#define	INT_VECTOR_PAGE_FAULT	0xE
#define INT_VECTOR_COPROC_ERR	0x10

#define	INT_VECTOR_IRQ0		0x20
#define	INT_VECTOR_IRQ8		0x28

#define CLOCK_IRQ		0
#define INT_VECTOR_SYS_CALL	0x90


//assert
#define	ASSERT
#ifdef	ASSERT
void assertion_failure(char* exp, char* file, char* base_file, int line);
#define assert(exp)		do{ if (!(exp))	assertion_failure(#exp, __FILE__, __BASE_FILE__, __LINE__); } while(0)
#else
#define assert(exp)
#endif


//ipc
#define SEND		1
#define RECEIVE		2
#define BOTH		3
#define SENDING		2
#define RECEIVING	4
#define ANY		(NR_TASKS + 10)
#define NO_TASK		(NR_TASKS + 20)
#define INTERRUPT	(NR_TASKS + 30)

enum msgtype {
	HARD_INT = 1,
	GET_TICKS,
};
#endif
